package br.ulbra.primeiroapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText edtVal1;
    EditText edtVal2;
    Button btnSomar;
    Button btnSubtrair;
    Button btnDividir;
    Button btnMultiplicar;
    TextView txtResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
            edtVal1 = findViewById((R.id.edtVal1));
            edtVal2 = findViewById((R.id.edtVal2));
            btnSomar = findViewById(R.id.btnSomar);
            btnSubtrair = findViewById(R.id.btnSubtrair);
            btnDividir = findViewById(R.id.btnDividir);
            btnMultiplicar = findViewById(R.id.btnMultiplicar);
            txtResultado = findViewById(R.id.txtResultado);
            btnSomar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                        double v1, v2, resultado;
                            v1=Double.parseDouble(edtVal1.getText().toString());
                            v2=Double.parseDouble(edtVal2.getText().toString());
                            resultado=v1+v2;
                            txtResultado.setText("Resultado: "+resultado);
                }

            });
        btnSubtrair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double v1, v2, resultado;
                v1=Double.parseDouble(edtVal1.getText().toString());
                v2=Double.parseDouble(edtVal2.getText().toString());
                resultado=v1-v2;
                txtResultado.setText("Resultado: "+resultado);
            }

        });
        btnDividir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double v1, v2, resultado;
                v1=Double.parseDouble(edtVal1.getText().toString());
                v2=Double.parseDouble(edtVal2.getText().toString());
                resultado=v1/v2;
                txtResultado.setText("Resultado: "+resultado);
                if(v2==0){
                    txtResultado.setText("Era pra dar infinito, uma pena não poder ser divido por 0");
                };
            }

        });
        btnMultiplicar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double v1, v2, resultado;
                v1=Double.parseDouble(edtVal1.getText().toString());
                v2=Double.parseDouble(edtVal2.getText().toString());
                resultado=v1*v2;
                txtResultado.setText("Resultado: "+resultado);
            }

        });
    }
}